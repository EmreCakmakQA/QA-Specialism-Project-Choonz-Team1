/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 43.68270307520027, "KoPercent": 56.31729692479973};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.3794583935032065, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.41967538991587217, 500, 1500, "read"], "isController": false}, {"data": [0.3913993479401619, 500, 1500, "create"], "isController": false}, {"data": [0.42069099630517925, 500, 1500, "update"], "isController": false}, {"data": [0.24128579662270855, 500, 1500, "Transaction Controller"], "isController": true}, {"data": [0.4248427999792132, 500, 1500, "delete"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 928720, 523030, 56.31729692479973, 1496.6263847015773, 0, 31772, 46.0, 361.0, 1583.0, 4866.520000000077, 1105.896838372496, 1634.3615044690541, 124.27070245658433], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["read", 231909, 125484, 54.10915488402779, 1523.3785838410918, 0, 30233, 182.0, 3527.100000000013, 4574.0, 6783.980000000003, 276.25480210846064, 516.0779814485988, 23.965736583876826], "isController": false}, {"data": ["create", 232494, 132680, 57.06813939284454, 1636.5009677668945, 0, 30490, 254.0, 4205.0, 4781.9000000000015, 7596.69000000005, 276.85239873490076, 398.65955512243744, 30.158244486476157], "isController": false}, {"data": ["update", 231405, 131778, 56.94691125948013, 1430.8168578898749, 0, 31772, 153.5, 3400.0, 4642.0, 7032.990000000002, 275.6669053186838, 369.55666486697334, 40.07104659506908], "isController": false}, {"data": ["Transaction Controller", 232494, 132680, 57.06813939284454, 5935.867889063787, 3, 49504, 3028.0, 9286.900000000001, 11712.800000000003, 17828.99, 276.7983427387671, 1620.5873452456424, 124.05018210936197], "isController": true}, {"data": ["delete", 230916, 131311, 56.865267023506384, 1363.69680749711, 0, 31233, 128.0, 3624.000000000029, 4608.950000000001, 6542.910000000014, 275.0915816372116, 337.08869467501177, 29.917006700723125], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 432, 0.08259564460929583, 0.046515634421569474], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset by peer", 211, 0.04034185419574403, 0.022719441812386942], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException", 284, 0.05429898858574078, 0.030579722628994745], "isController": false}, {"data": ["404", 31951, 6.108827409517619, 3.4403264708415886], "isController": false}, {"data": ["Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 468264, 89.52909010955395, 50.420363511069], "isController": false}, {"data": ["Non HTTP response code: java.net.BindException", 1493, 0.28545207731870065, 0.16075889396158152], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:8082 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 20395, 3.899393916218955, 2.196033250064605], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 928720, 523030, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 468264, "404", 31951, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:8082 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 20395, "Non HTTP response code: java.net.BindException", 1493, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 432], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["read", 231909, 125484, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 120261, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:8082 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 5050, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 121, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset by peer", 52, null, null], "isController": false}, {"data": ["create", 232494, 132680, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 127100, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:8082 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 5442, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 94, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset by peer", 44, null, null], "isController": false}, {"data": ["update", 231405, 131778, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 113565, "404", 13112, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:8082 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 4935, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 106, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset by peer", 60], "isController": false}, {"data": ["Transaction Controller", 1996, 1777, "Non HTTP response code: java.net.BindException", 1493, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException", 284, null, null, null, null, null, null], "isController": false}, {"data": ["delete", 230916, 131311, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 107338, "404", 18839, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:8082 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 4968, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 111, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset by peer", 55], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
